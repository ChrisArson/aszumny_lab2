//
//  aszumny_lab2App.swift
//  aszumny_lab2
//
//  Created by student on 27/04/2024.
//

import SwiftUI

@main
struct aszumny_lab2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
