//
//  ContentView.swift
//  aszumny_lab2
//
//  Created by student on 27/04/2024.
//

import SwiftUI

struct ContentView: View {
    var emojis1 = ["😄","😍","🤓","😝","😎","😖","🤩","🥺","🤬","🤓","🤩"]
    @State var isDisabled : Bool = false
    @State var cardCount : Int = 2
    
    var body: some View {
        VStack {
            ScrollView{
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], content: {
                    ForEach(0..<cardCount, id: \.self) { index in
                        CardView(emoji: emojis1[index])
                    }
                }).foregroundColor(.white)

            }
        }
        .padding()
        HStack{
            adjustCardNumber(by: +2, symbol: "plus.app")
            Spacer()
            Text(String(cardCount))
            adjustCardNumber(by: -2, symbol: "minus.square")

        }
    }
    func adjustCardNumber(by offset: Int, symbol: String) -> some View{
        print(cardCount)
        if (cardCount>5 || cardCount<2){
            self.isDisabled=true
        }else{
            self.isDisabled=false
        }
        print(isDisabled)
        return Button(action: {cardCount += offset}, label: {
            Image(systemName: symbol)
        }).disabled(isDisabled)
        .font(.largeTitle)
        .padding()
        
        
    }
}

#Preview {
    ContentView()
}
